import React, { useState } from "react";
import { useLocation } from "react-router-dom";
import "../styles/ThankYou.css";

const ThankYouPage = () => {
  const location = useLocation();
  const { orderNumber, orderId } = location.state || {};
  
  const [rating, setRating] = useState(0);
  const [feedback, setFeedback] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = () => {
    if (rating > 0 || feedback.trim()) {
      setSubmitted(true);
    }
  };

  return (
    <div className="thankyou-page">
      <h1>Thank You!</h1>
      <p>Your order has been received with love 💛</p>
      
      {orderNumber && (
        <div style={{
          background: "#f0f8ff",
          padding: "20px",
          borderRadius: "8px",
          marginBottom: "30px",
          border: "2px solid #4CAF50",
          textAlign: "center"
        }}>
          <h2 style={{ color: "#4CAF50", margin: "0 0 10px 0" }}>Order Confirmation</h2>
          <p style={{ margin: "5px 0", fontSize: "1.1rem" }}>
            <strong>Order Number:</strong> {orderNumber}
          </p>
          {orderId && (
            <p style={{ margin: "5px 0", fontSize: "0.95rem", color: "#666" }}>
              Order ID: {orderId}
            </p>
          )}
          <p style={{ margin: "15px 0 0 0", fontSize: "0.9rem", color: "#666" }}>
            We'll start preparing your delicious order right away!
          </p>
        </div>
      )}

      {!submitted ? (
        <>
          <h2 style={{ marginTop: "30px" }}>Rate Your Experience</h2>
          <div className="stars">
            {[1, 2, 3, 4, 5].map((star) => (
              <span
                key={star}
                className={star <= rating ? "star selected" : "star"}
                onClick={() => setRating(star)}
              >
                ★
              </span>
            ))}
          </div>

          <textarea
            placeholder="Leave us a sweet message..."
            value={feedback}
            onChange={(e) => setFeedback(e.target.value)}
          />

          <button onClick={handleSubmit}>Send Feedback</button>
        </>
      ) : (
        <p className="thanks-message">
          Thanks for your feedback! You're the sweetest 🍰
        </p>
      )}

      <button
        className="back-home"
        onClick={() => (window.location.href = "/")}
      >
        Back to Home
      </button>
    </div>
  );
}

export default ThankYouPage;