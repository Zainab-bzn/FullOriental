import React, { useState, useEffect } from "react";
import "../styles/Cakes.css";
import { Link } from "react-router-dom";

// Import all cake images
import birthdayCake from "../assets/BirthdayCake.JPG";
import weddingCake from "../assets/weddingCake.JPG";
import mothersDayCake from "../assets/MothersDayCake.JPG";
import anniversaryCake from "../assets/anniversaryCake.JPG";
import genderRevealCake from "../assets/genderRevealCake.JPG";
import graduationCake from "../assets/GradautionCake.JPG";
import valentineCake from "../assets/valentineCake.JPG";
import newYearCake from "../assets/newYearCake.JPG";
import iceCreamCake from "../assets/iceCreamCake.JPG";
import englishCake from "../assets/EnglishCake.JPG";

// Image mapping
const imageMap = {
  "BirthdayCake.JPG": birthdayCake,
  "weddingCake.JPG": weddingCake,
  "MothersDayCake.JPG": mothersDayCake,
  "anniversaryCake.JPG": anniversaryCake,
  "genderRevealCake.JPG": genderRevealCake,
  "GradautionCake.JPG": graduationCake,
  "valentineCake.JPG": valentineCake,
  "newYearCake.JPG": newYearCake,
  "iceCreamCake.JPG": iceCreamCake,
  "EnglishCake.JPG": englishCake,
};

const Cakes = () => {
  const [cakes, setCakes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeIndex, setActiveIndex] = useState(null);

  useEffect(() => {
    fetchCakes();
  }, []);

  const fetchCakes = async () => {
    try {
      const response = await fetch("http://localhost:8080/cake-types");
      if (!response.ok) {
        throw new Error("Failed to fetch cakes");
      }
      const data = await response.json();
      setCakes(data);
      setLoading(false);
    } catch (err) {
      console.error("Error fetching cakes:", err);
      setError(err.message);
      setLoading(false);
    }
  };

  const handleTap = (index) => {
    setActiveIndex(index === activeIndex ? null : index);
  };

  if (loading) return <div className="cakes-page"><p>Loading cakes...</p></div>;
  if (error) return <div className="cakes-page"><p>Error: {error}</p></div>;

  return (
    <div className="cakes-page">
      {/* HEADER  */}
      <div className="catalog-header">
        <Link to="/menu" className="back-arrow">
          ❮ Back
        </Link>
        <h1>Cakes</h1>
      </div>

      {/* ALL CAKES */}
      <div className="catalog-container">
        {cakes.map((cake, index) => (
          <div 
            key={cake.id} 
            className={`catalog-box ${index === activeIndex ? 'active' : ''}`} 
            onClick={() => handleTap(index)} 
          >
            <img src={imageMap[cake.photo_path]} alt={cake.name} />

            <div className="custom-overlay">
              <Link
                to={`/custom-cake?id=${cake.id}&name=${encodeURIComponent(cake.name)}&image=${encodeURIComponent(cake.photo_path)}`}
                className="custom-btn"
                onClick={(e) => e.stopPropagation()} 
              >
                Custom Cake
              </Link>
            </div>

            <div className="cake-label">{cake.name}</div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Cakes;