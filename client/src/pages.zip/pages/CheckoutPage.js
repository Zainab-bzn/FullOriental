import React, { useState, useEffect } from "react";
import CheckoutItem from "../components/CheckoutItem";
import "../styles/CheckoutPage.css";
import { useNavigate } from "react-router-dom";


const CheckoutPage = () => {
  const navigate = useNavigate();
  const [cartItems, setCartItems] = useState([]);
  const [customCakes, setCustomCakes] = useState([]);
  const [totalPrice, setTotalPrice] = useState(0);
  const [loading, setLoading] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    address: "",
  });
  
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    // Check authentication
    const userId = localStorage.getItem("userId");
    const userInfo = localStorage.getItem("user");
    
    if (!userId || !userInfo) {
      alert("Please login to checkout");
      navigate("/account", { replace: true });
      return;
    }
    
    setIsAuthenticated(true);
    const user = JSON.parse(userInfo);
    
    // Pre-fill form with user data
    setFormData({
      name: user.username || "",
      email: user.email || "",
      address: "",
    });
    
    // Load cart from localStorage
    const cart = JSON.parse(localStorage.getItem("cart")) || [];
    
    if (cart.length === 0) {
      alert("Your cart is empty");
      navigate("/menu", { replace: true });
      return;
    }
    
    setCartItems(cart);
    loadCustomCakeDetails(cart);
  }, [navigate]);

  const loadCustomCakeDetails = async (cart) => {
    try {
      // Get details for custom cakes
      const customCakeIds = cart
        .filter((item) => item.type === "custom_cake")
        .map((item) => item.customCakeId);

      if (customCakeIds.length > 0) {
        // Fetch custom cake details from server
        const response = await fetch(
          `http://localhost:8080/custom-cakes/${customCakeIds.join(",")}`
        );
        
        if (response.ok) {
          const data = await response.json();
          setCustomCakes(data);
        }
      }

      // Calculate total
      const total = cart.reduce((sum, item) => sum + item.price, 0);
      setTotalPrice(total);
      setLoading(false);
    } catch (error) {
      console.error("Error loading custom cake details:", error);
      setLoading(false);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handlePlaceOrder = async () => {
    if (!formData.name || !formData.email || !formData.address) {
      alert("Please fill out all form fields before placing order.");
      return;
    }

    setIsSubmitting(true);

    try {
      const userId = localStorage.getItem("userId");
      
      // Format order items properly
      const orderItems = cartItems.map((item) => {
        if (item.type === "custom_cake") {
          return {
            name: item.name,
            type: "custom_cake",
            customCakeId: item.customCakeId,
            quantity: item.quantity || 1,
            price: item.price,
          };
        } else {
          return {
            name: item.name,
            type: item.type || "cupcake",
            quantity: item.quantity || 1,
            price: item.price,
          };
        }
      });

      // Create order
      const response = await fetch("http://localhost:8080/order", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name: formData.name,
          email: formData.email,
          address: formData.address,
          items: orderItems,
          totalPrice: totalPrice,
          userId: parseInt(userId),
        }),
      });

      if (!response.ok) {
        const error = await response.json();
        alert("Failed to place order: " + error.message);
        setIsSubmitting(false);
        return;
      }

      const orderData = await response.json();

      // Clear cart from localStorage
      localStorage.removeItem("cart");

      // Show success and redirect
      alert(
        `Thank you for your order, ${formData.name}! Order #${orderData.orderNumber} has been placed.`
      );
      
      navigate("/thankyou", {
        state: {
          orderNumber: orderData.orderNumber,
          orderId: orderData.orderId,
        },
      });
    } catch (error) {
      console.error("Error placing order:", error);
      alert("An error occurred while placing your order.");
      setIsSubmitting(false);
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="checkoutPage">
        <h1 className="checkoutTitle">Checkout</h1>
        <p>Loading...</p>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="checkoutPage">
        <h1 className="checkoutTitle">Checkout</h1>
        <p>Loading your cart...</p>
      </div>
    );
  }

  return (
    <div className="checkoutPage">
      <h1 className="checkoutTitle">Checkout</h1>

      {cartItems.length > 0 ? (
        <>
          <section className="itemsSection">
            <h2 className="sectionTitle">Order Items</h2>
            <div className="itemsGrid">
              {cartItems.map((item, index) => (
                <div key={index} className="checkout-item-card">
                  <div className="item-info">
                    <h3>{item.name}</h3>
                    <p className="item-type">Type: {item.type}</p>
                    {item.type === "custom_cake" && (
                      <p className="item-details">Custom Cake ID: {item.customCakeId}</p>
                    )}
                    <p className="item-quantity">Qty: {item.quantity || 1}</p>
                  </div>
                  <div className="item-price">${item.price.toFixed(2)}</div>
                </div>
              ))}
            </div>
          </section>

          <h2 className="totalPrice">Total Price: ${totalPrice.toFixed(2)}</h2>

          <form className="checkoutForm" onSubmit={(e) => e.preventDefault()}>
            <h2 style={{ marginBottom: "20px" }}>Delivery Information</h2>
            
            <div className="formGroup">
              <label htmlFor="name">Name:</label>
              <input
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleInputChange}
                required
              />
            </div>

            <div className="formGroup">
              <label htmlFor="email">Email:</label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
                required
              />
            </div>

            <div className="formGroup">
              <label htmlFor="address">Delivery Address:</label>
              <textarea
                id="address"
                name="address"
                value={formData.address}
                onChange={handleInputChange}
                placeholder="Enter your full delivery address"
                required
              ></textarea>
            </div>

            <button
              className="placeOrderButton"
              onClick={handlePlaceOrder}
              disabled={isSubmitting}
            >
              {isSubmitting ? "Processing..." : "Place Order"}
            </button>
          </form>
        </>
      ) : (
        <div style={{ textAlign: "center", padding: "40px" }}>
          <p>Your cart is empty</p>
          <button
            className="placeOrderButton"
            onClick={() => navigate("/menu")}
            style={{ marginTop: "20px" }}
          >
            Continue Shopping
          </button>
        </div>
      )}
    </div>
  );
};

export default CheckoutPage;
