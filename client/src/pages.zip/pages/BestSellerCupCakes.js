import React from 'react';
import { Link } from 'react-router-dom';
import { bestSellerBoxes } from '../data/bestSellerBoxes';
import CupcakeCart from '../components/CupcakeCart';
import '../styles/BestSellerCupCakes.css';

const  BestsellerPage = ()=> {
  return (
    <div className="menu-page">
      <div className="catalog-header">
        <Link to="/cupCakeHome" className="back-arrow">
          ❮ Back
        </Link>
        <h1>Best Seller Boxes</h1>
      </div>
      <div className="cupcake-grid">
        {bestSellerBoxes.map((box) => (
          <CupcakeCart key={box.id} cupcake={box} />
        ))}
      </div>
    </div>
  );
}

export default BestsellerPage;
