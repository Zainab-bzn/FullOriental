import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "../styles/Account.css";
import axios from "axios";

const Account = () => {
  const navigate = useNavigate();
  const [showPassword, setShowPassword] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userInfo, setUserInfo] = useState(null);

  // LOGIN
  const [username, setUsername] = useState(""); 
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");

  // REGISTER
  const [regUsername, setRegUsername] = useState("");
  const [regEmail, setRegEmail] = useState("");
  const [regPassword, setRegPassword] = useState("");
  const [regMsg, setRegMsg] = useState("");

  useEffect(() => {
    // Check if user is already logged in
    const userId = localStorage.getItem("userId");
    const user = localStorage.getItem("user");
    if (userId && user) {
      setIsLoggedIn(true);
      setUserInfo(JSON.parse(user));
    }
  }, []);

  function handleLogout() {
    localStorage.removeItem("userId");
    localStorage.removeItem("user");
    setIsLoggedIn(false);
    setUserInfo(null);
    setMessage("✔ Logged out successfully!");
  }

  async function handleRegister(e) {
    e.preventDefault();
    setRegMsg("");

    try {
      const res = await axios.post("http://localhost:8080/register", {
        username: regUsername,
        email: regEmail,
        password: regPassword,
      });

      // Store userId after successful registration
      localStorage.setItem("userId", res.data.userId);
      
      // Also create and store user object for consistency
      const userData = {
        id: res.data.userId,
        username: regUsername,
        email: regEmail
      };
      localStorage.setItem("user", JSON.stringify(userData));
      
      // Update state to show logged in UI
      setIsLoggedIn(true);
      setUserInfo(userData);
      
      setRegMsg("✔ Registered successfully! You can now customize cakes. Redirecting...");
      setRegUsername("");
      setRegEmail("");
      setRegPassword("");
      
      // Redirect to cakes page after 1.5 seconds
      setTimeout(() => {
        navigate("/cakes");
      }, 1500);
    } catch (err) {
      if (err?.response?.status === 409) setRegMsg("❌ Email already exists");
      else if (err?.response?.status === 400) setRegMsg("❌ Missing fields");
      else setRegMsg("❌ Registration failed");
    }
  }

  async function handleLogin(e) {
    e.preventDefault();
    setMessage("");

    try {
      const res = await axios.post("http://localhost:8080/login", {
        identifier: username,
        password: password,
      });

      // Store user data in localStorage
      localStorage.setItem("user", JSON.stringify(res.data.user));
      localStorage.setItem("userId", res.data.user.id);
      
      // Update state to show logged in UI
      setIsLoggedIn(true);
      setUserInfo(res.data.user);
      
      setMessage("✔ Login successful (10% will be discounted from your total!)");
      
      // Clear form
      setUsername("");
      setPassword("");
      
      // Redirect to cakes page after 1 second
      setTimeout(() => {
        navigate("/cakes");
      }, 1000);
    } catch (err) {
      setMessage("❌ Incorrect username/email or password");
    }
  }

  return (
    <div className="account-page">
      <div className="breadcrumb">Home / My Account</div>
      <h1 className="account-title">My Account</h1>

      {/* SHOW MESSAGES */}
      {message && <p className="login-message" style={{textAlign: "center", marginBottom: "20px"}}>{message}</p>}

      {/* SHOW USER INFO IF LOGGED IN */}
      {isLoggedIn && userInfo && (
        <div style={{
          background: "#f0f8ff",
          padding: "20px",
          borderRadius: "8px",
          marginBottom: "30px",
          textAlign: "center",
          border: "2px solid #4CAF50"
        }}>
          <h2 style={{ color: "#4CAF50", margin: "0 0 10px 0" }}>Welcome, {userInfo.username}!</h2>
          <p style={{ margin: "5px 0", color: "#333" }}>Email: {userInfo.email}</p>
          <button
            onClick={handleLogout}
            style={{
              marginTop: "15px",
              padding: "10px 20px",
              backgroundColor: "#ff6b6b",
              color: "white",
              border: "none",
              borderRadius: "5px",
              cursor: "pointer",
              fontSize: "14px"
            }}
          >
            Logout
          </button>
        </div>
      )}

      {!isLoggedIn && (
        <>
          {/* LOGIN CARD */}
      <form className="login-card" onSubmit={handleLogin}>
        <div className="form-group">
          <label>Username or Email Address *</label>
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
        </div>

        <div className="form-group">
          <label>Password *</label>
          <div className="password-wrapper">
            <input
              type={showPassword ? "text" : "password"}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <span
              className="toggle-pass"
              onClick={() => setShowPassword(!showPassword)}
            >
              {showPassword ? "👁" : "👁‍🗨"}
            </span>
          </div>
        </div>

        <div className="remember-row">
          <input type="checkbox" id="remember" />
          <label htmlFor="remember">Remember me</label>
        </div>

        <button className="login-btn" type="submit">
          LOG IN
        </button>
      </form>

      {/* REGISTER CARD (same style class so design stays consistent) */}
      <form className="login-card" onSubmit={handleRegister} style={{ marginTop: "20px" }}>
        <h2 style={{ marginBottom: "12px" }}>Register</h2>

        <div className="form-group">
          <label>Username *</label>
          <input
            type="text"
            value={regUsername}
            onChange={(e) => setRegUsername(e.target.value)}
          />
        </div>

        <div className="form-group">
          <label>Email *</label>
          <input
            type="email"
            value={regEmail}
            onChange={(e) => setRegEmail(e.target.value)}
          />
        </div>

        <div className="form-group">
          <label>Password *</label>
          <input
            type="password"
            value={regPassword}
            onChange={(e) => setRegPassword(e.target.value)}
          />
        </div>

        <button className="login-btn" type="submit">
          REGISTER
        </button>

        {regMsg && <p className="login-message">{regMsg}</p>}
      </form>
        </>
      )}
    </div>
  );
};

export default Account;
