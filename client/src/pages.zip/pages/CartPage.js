import CupcakeCart from '../components/CupcakeCart';
import '../styles/AddToCart.css';

const CartPage = () => {
  const cartItems = JSON.parse(localStorage.getItem('cart')) || [];

  return (
    <div className="add-to-cart-page">
      <h1>Your Cart</h1>

      {cartItems.length === 0 ? (
        <p>Your cart is empty.</p>
      ) : (
        <section className="cart-section">
          <h2>Items</h2>
          <div className="cart-items">
            {cartItems.map(item => (
              <CupcakeCart key={item.id} cupcake={item} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
};

export default CartPage;
