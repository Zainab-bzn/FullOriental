
CREATE DATABASE IF NOT EXISTS patisserie;
USE patisserie;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(100) NOT NULL UNIQUE,
  email VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS individual_cupcakes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  description TEXT,
  price DECIMAL(10, 2) NOT NULL,
  image VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS best_seller_boxes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  description TEXT,
  price DECIMAL(10, 2) NOT NULL,
  image VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS cakes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  description TEXT,
  price DECIMAL(10, 2),
  image VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  description TEXT,
  price DECIMAL(10, 2) NOT NULL,
  category VARCHAR(50),
  image VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS cake_types (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  photo_path VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS cake_tiers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tier_name VARCHAR(100) NOT NULL,
  servings_min INT,
  servings_max INT,
  price DECIMAL(10, 2) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS cake_fillings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  filling_name VARCHAR(100) NOT NULL,
  price DECIMAL(10, 2) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS cake_addons (
  id INT AUTO_INCREMENT PRIMARY KEY,
  addon_name VARCHAR(100) NOT NULL,
  price DECIMAL(10, 2) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS cart (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  product_id INT,
  item_name VARCHAR(150) NOT NULL,
  product_type VARCHAR(50),
  quantity INT DEFAULT 1,
  price DECIMAL(10, 2) NOT NULL,
  image VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE KEY unique_cart_item (user_id, product_id)
);

CREATE TABLE IF NOT EXISTS custom_cakes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  cake_type_id INT,
  cake_type VARCHAR(150) NOT NULL,
  tier_id INT,
  filling_id INT,
  addons JSON,
  notes TEXT,
  reference_photo VARCHAR(255),
  total_price DECIMAL(10, 2) NOT NULL,
  user_id INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (cake_type_id) REFERENCES cake_types(id) ON DELETE SET NULL,
  FOREIGN KEY (tier_id) REFERENCES cake_tiers(id) ON DELETE SET NULL,
  FOREIGN KEY (filling_id) REFERENCES cake_fillings(id) ON DELETE SET NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_number VARCHAR(50) UNIQUE NOT NULL,
  customer_name VARCHAR(150) NOT NULL,
  customer_email VARCHAR(100) NOT NULL,
  customer_address TEXT NOT NULL,
  total_amount DECIMAL(10, 2) NOT NULL,
  status VARCHAR(50) DEFAULT 'pending',
  user_id INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS order_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  item_name VARCHAR(150) NOT NULL,
  item_type VARCHAR(50),
  custom_cake_id INT,
  quantity INT DEFAULT 1,
  price DECIMAL(10, 2) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  FOREIGN KEY (custom_cake_id) REFERENCES custom_cakes(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS feedback (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  order_id INT,
  stars INT DEFAULT 5,
  comment TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE SET NULL
);


-- Individual Cupcakes
INSERT INTO individual_cupcakes (name, description, price, image) VALUES
('Cookie Monster', 'Delicious cookie-flavored cupcake with chocolate chips', 5.95, '/assets/cookie-monster.jpg'),
('Rainbow Cupcake', 'Colorful rainbow-layered cupcake with sprinkles', 5.95, '/assets/rainbow.jpg'),
('Red Velvet Cupcake', 'Classic red velvet with cream cheese frosting', 4.95, '/assets/red-velvet.jpg'),
('Peanut Buttercream Cupcake', 'Rich peanut butter flavor with creamy frosting', 4.95, '/assets/peanut-butter.jpg'),
('Poop Emoji Cupcake', 'Fun emoji-shaped cupcake for special occasions', 5.95, '/assets/poop-emoji.jpg');

-- Best Seller Boxes
INSERT INTO best_seller_boxes (name, description, price, image) VALUES
('6 PC Fun Assortment', 'Mix of 6 fun assorted cupcakes', 35.95, '/assets/fun-assortment.jpg'),
('Happy Birthday Dozen Box', 'A dozen birthday-themed cupcakes', 59.50, '/assets/hbd-dozen.jpg'),
('6 PC Celebration Cupcakes', 'Perfect for celebrations and parties', 27.95, '/assets/celebration.jpg'),
('6 PC Rainbow Cupcakes', 'Rainbow-colored assorted cupcakes', 35.95, '/assets/rainbow-box.jpg');

-- Cakes
INSERT INTO cakes (name, description, image) VALUES
('Birthday Cake', 'Classic birthday cake with customizable flavors', '/assets/BirthdayCake.JPG'),
('Wedding Cake', 'Elegant wedding cake options', '/assets/weddingCake.JPG'),
('Mother\'s Day Cake', 'Elegant cake perfect for Mother\'s Day', '/assets/MothersDayCake.JPG'),
('Anniversary Cake', 'Special celebration cake for anniversaries', '/assets/anniversaryCake.JPG'),
('Gender Reveal Cake', 'Fun and exciting gender reveal cake', '/assets/genderRevealCake.JPG'),
('Graduation Cake', 'Perfect cake to celebrate graduation', '/assets/GradautionCake.JPG'),
('Valentine Cake', 'Romantic Valentine\'s Day cake', '/assets/valentineCake.JPG'),
('New Year Cake', 'Celebrate the new year with style', '/assets/newYearCake.JPG'),
('Ice Cream Cake', 'Delicious ice cream layered cake', '/assets/iceCreamCake.JPG'),
('English Cake', 'Traditional English-style cake', '/assets/EnglishCake.JPG');


-- Cake Types
INSERT INTO cake_types (name, photo_path) VALUES
('Birthday Cake', 'BirthdayCake.JPG'),
('Wedding Cake', 'weddingCake.JPG'),
('Mother\'s Day Cake', 'MothersDayCake.JPG'),
('Anniversary Cake', 'anniversaryCake.JPG'),
('Gender Reveal Cake', 'genderRevealCake.JPG'),
('Graduation Cake', 'GradautionCake.JPG'),
('Valentine Cake', 'valentineCake.JPG'),
('New Year Cake', 'newYearCake.JPG'),
('Ice Cream Cake', 'iceCreamCake.JPG'),
('English Cake', 'EnglishCake.JPG');

-- Cake Tiers
INSERT INTO cake_tiers (tier_name, servings_min, servings_max, price) VALUES
('8–12 servings', 8, 12, 20.00),
('18–24 servings', 18, 24, 35.00),
('25–40 servings', 25, 40, 50.00);

-- Cake Fillings
INSERT INTO cake_fillings (filling_name, price) VALUES
('Chocolate', 5.00),
('Vanilla', 5.00),
('Vanilla & Chocolate', 6.00),
('Strawberry', 6.00),
('Lemon', 6.00),
('Caramel', 7.00);

-- Cake Add-ons
INSERT INTO cake_addons (addon_name, price) VALUES
('Nuts', 2.00),
('Fruits', 3.00),
('Crema', 2.00),
('Extra Sprinkles', 1.50),
('Custom Message', 3.00),
('Gold Leaf', 5.00);
